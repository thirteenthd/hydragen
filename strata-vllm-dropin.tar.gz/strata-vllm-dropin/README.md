# Strata vLLM PagedMoE Engine Drop-in Package

This drop-in package upgrades an existing [Strata](https://github.com/ISTA-DASLab/Strata) installation with the **vLLM PagedMoE Engine backend (`--engine vllm`)**.

It bridges on-the-fly GPU dequantization, Triton Fused MoE with slot indirection, multi-slot continuous batching, and conversation prefix caching directly into Strata's OpenAI-compatible server and web monitor — **without requiring offline SafeTensors conversion**.

---

## Key Features

1. **Direct GGUF MoE Loading (Zero Conversion):** Reads your existing `Qwen3.8-Flash-Next-GSQ-RCO-*.gguf` shards and resident expert packs directly.
2. **On-the-Fly GPU Dequantization:** Dequantizes GSQ IQ3_XXS / IQ2_XS / IQ4_NL blocks into FP16 directly on the GPU during PCIe DMA transfers using custom Ampere kernels (`libstrata_iq_kernels.so`).
3. **Continuous Batching & Multi-Turn Prefix Caching:** Automatically tracks session contexts, caching conversation prefixes across agent/chat turns (achieving 65–85% token reuse on multi-turn conversations).
4. **Full Strata Telemetry Integration:** Works with the existing Web Monitor (`http://localhost:8080/`), displaying real-time VRAM expert caching (2,270 experts / 3.7 GB), live prefill speed gauges, and MTP speculation rates.

---

## Hardware Requirements

* **GPU:** NVIDIA Ampere, Ada Lovelace, or Blackwell (RTX 3060 12GB, RTX 3080/3080 Ti, RTX 3090, RTX 4070/4080/4090).
* **VRAM:** 12 GB minimum.
* **System RAM:**
  * **64 GB RAM:** Recommended for running `IQ3_XXS` with the entire 41 GB expert arena locked in host RAM.
  * **32 GB RAM:** Recommended to run `IQ2_XS` (runs at ~42–46 tok/s on an RTX 3060!) or use `--resident-experts` for NVMe SSD streaming.
* **Strata:** An existing working Strata setup with model weights already downloaded.

---

## Quick Installation (Under 1 Minute)

### Option A: Using the Automated Installer (Linux)

From the extracted package directory:

```bash
# Point to your Strata installation directory
./install.sh /path/to/Strata
```

The script will:
1. Verify prerequisites and install `requirements-vllm.txt` (`torch`, `triton`, `gguf`, `numpy`, `psutil`).
2. Copy `vllm_engine.py`, `strata_gguf.py`, and `libstrata_iq_kernels.so` into `serve/`.
3. Patch `serve/server.py` to enable `--engine vllm`.
4. Provide `run_vllm.sh`.

### Option B: Manual Installation

1. Copy the files into your Strata repository:
   ```bash
   cp serve/vllm_engine.py /path/to/Strata/serve/
   cp serve/strata_gguf.py /path/to/Strata/serve/
   cp serve/libstrata_iq_kernels.so /path/to/Strata/serve/
   ```
2. Apply the patch to `serve/server.py`:
   ```bash
   cd /path/to/Strata
   git apply /path/to/strata-vllm-dropin/vllm-server.patch
   # Or directly replace serve/server.py with the provided pre-patched serve/server.py
   ```
3. Install Python dependencies in your environment:
   ```bash
   pip install -r requirements-vllm.txt
   ```

---

## Preservation & Switching Back

**Your friend's stock Strata installation is 100% preserved.**

1. **Non-destructive & Additive:**
   - The drop-in only registers the optional `--engine vllm` flag.
   - None of their model GGUFs, weights, packs, or configs are altered.
   - Their original Strata launch commands (e.g. `./run-iq3_xxs.sh` or `--engine strata`) continue to run their stock Strata setup completely untouched.
   - They can switch back and forth at any time simply by toggling between `--engine strata` and `--engine vllm`.

2. **1-Click Clean Revert / Uninstall:**
   - The installer automatically creates a safety backup `serve/server.py.orig_backup`.
   - To completely remove the drop-in and restore Strata to its exact original state:
     - On Linux: `./uninstall.sh`
     - On Windows: `uninstall.bat`

---

## Running the Server

Start the server using `--engine vllm`:

```bash
cd /path/to/Strata
python3 -m serve.server --engine vllm --config strata-iq3_xxs.json --port 8080 --api-monitor --no-api-key
```

Or simply run the helper script:
```bash
./run_vllm.sh
```

---

## Accessing the Endpoints

* **Web Monitor & Live Chat:** Open [http://localhost:8080/](http://localhost:8080/) in any web browser.
* **OpenAI-Compatible API:** [http://localhost:8080/v1](http://localhost:8080/v1)
  * Model ID: `qwen3.8-flash-next-iq3_xxs`
  * Compatible with Cursor, Continue, Letta, Hermes Agent, LangChain, LlamaIndex, etc.

### Example Curl Request:
```bash
curl http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3.8-flash-next-iq3_xxs",
    "messages": [{"role": "user", "content": "Explain prefix caching in one sentence."}],
    "max_tokens": 100
  }'
```
